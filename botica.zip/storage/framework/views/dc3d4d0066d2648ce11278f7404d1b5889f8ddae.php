

<?php $__env->startSection('content'); ?>


<div class="container">

<div class="row">
<div class="col-md-8">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h4>Por Favor corriga los siguientes errores   </h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>

<form action="<?php echo e(route('casillas.update',$casillas->rc_id)); ?>" method="POST" id="frm_formulario" @submit="checkForm">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>

  <p v-if="errors.length">
    <b style="color: red;">Por favor, corrija el(los) siguiente(s) error(es):</b>
    <ul>
      <li v-for="error in errors">{{error}}</li>
    </ul>
  </p>





    <div class="form-row">
        <div class="form-group col-md-12">
            <label for="producto">Rack *</label>
            <select class="form-control" name="cbo_rack_id" id="selected_rack" v-model="selected_rack">
            <option value="">Seleccione un Rack</option>
                <?php $__currentLoopData = $filas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->rack_id); ?>"  <?php if($casillas->rack_id ==$item->rack_id): ?> selected <?php endif; ?>><?php echo e($item->rack_nombre); ?></option>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>


  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="producto">Casilla *</label>
      <input type="text" class="form-control" v-model="nombre" style="text-transform:uppercase;" 
        onkeyup="javascript:this.value=this.value.toUpperCase();" name="nombre" id="nombre" placeholder="Nombre" value="<?php echo e($casillas->rc_nombre); ?>">
    </div>
  
  </div>

 



  <button type="submit" class="btn btn-primary">Registrar</button>
  <button type="reset" class="btn btn-danger">Cancelar</button>

</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/racks_casillas.js')); ?>" ></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/racks_casillas/edit.blade.php ENDPATH**/ ?>