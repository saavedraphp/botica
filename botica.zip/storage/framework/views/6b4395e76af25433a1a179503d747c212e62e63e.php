

<?php $__env->startSection('content'); ?>



<div class="container">

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h4>Por Favor corriga los siguientes errores   </h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>

<?php if(Session::get('operacion')=='1'): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>

<?php if(Session::get('operacion')=='0'): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <?php echo e(Session::get('message')); ?>

  </div>

<?php endif; ?>



<form action="<?php echo e(route('upload_mages',$empresa->empr_id)); ?>" method="POST" 
id="frm_formulario" enctype="multipart/form-data" >

<?php echo csrf_field(); ?>

<p v-if="errors.length">
    <b style="color: red;">Por favor, corrija el(los) siguiente(s) error(es):</b>
    <ul>
      <li v-for="error in errors">{{error}}</li>
    </ul>
  </p>


  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Empresa</label>
      <?php echo e($empresa->empr_nombre); ?>  -  <?php echo e($empresa->empr_ruc); ?>

    </div>
  </div>


  <div class="form-group">
        <label for="inputAddress">Imagen</label>
        <div class="input-group mb-3">

            <div class="input-group-prepend">
                <span class="input-group-text">Upload</span>
            </div>

            <div class="custom-file">
                <input type="file" class="custom-file-input" id="img_cabecera"    ref="imagen" name="img">
                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
            </div>
        
        </div>
  </div>


  <div class="form-group">
  
    <img src="/img/cabecera_reporte/<?php if(empty($empresa->empr_ruta_img_reporte)): ?>defauld_1090_163.jpg <?php else: ?><?php echo e($empresa->empr_ruta_img_reporte); ?> <?php endif; ?>" class="img-fluid" alt="Responsive image">

  </div>

 

  <button type="submit" class="btn btn-primary">Subir Imagen</button>

  <?php if(!empty($empresa->empr_ruta_img_reporte)): ?>
    <a href="<?php echo e(route('dropImages',$empresa->empr_id)); ?>" 
    onclick="return confirm('Estas Seguro de Borrar la Imagen de la Empresa Id:<?php echo e($empresa->empr_id); ?>');">
    <button type="button" class="btn btn-danger">Eliminar Imagen</button></a>
  <?php endif; ?>
</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/empresa_imagen.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/empresas/images.blade.php ENDPATH**/ ?>