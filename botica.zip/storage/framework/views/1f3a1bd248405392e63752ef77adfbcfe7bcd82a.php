

<?php $__env->startSection('content'); ?>
<?php $empresas = app('App\Services\Empresas'); ?>
<?php $presentaciones = app('App\Services\Presentaciones'); ?>
<div class="container">

<div class="row">
<div class="col-md-8">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h4>Por Favor corriga los siguientes errores   </h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>


<form action="<?php echo e(route('productos.update',$producto->prod_id)); ?>" method="POST"  id="frm_formulario" @submit="checkForm">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>

  <p v-if="errors.length">
    <b style="color: red;">Por favor, corrija el(los) siguiente(s) error(es):</b>
    <ul>
      <li v-for="error in errors">{{error}}</li>
    </ul>
  </p>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="producto">Producto</label>
      <input type="text" class="form-control" v-model="producto" name="producto" id="producto" placeholder="Nombre" value="<?php echo e($producto->prod_nombre); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Codigo</label>
      <input type="text" class="form-control" name="codigo_producto" id="inputPassword4" placeholder="Codigo" value="<?php echo e($producto->prod_codigo); ?>">
    </div>
  </div>


  <div class="form-row">
    <div class="form-group col-md-6">
        <label for="inputAddress">Sku</label>
        <input type="text" class="form-control" id="inputAddress" placeholder="sku" name="sku" value="<?php echo e($producto->prod_sku); ?>">

    </div>

    <div class="form-group col-md-6">
        <label for="inputAddress">Ean</label>
        <input type="text" class="form-control" id="inputAddress" placeholder="Ean" name="ean" value="<?php echo e($producto->prod_ean); ?>">
    </div>
  </div>








  <div class="form-row">
  <div class="form-group col-md-6">
      <label for="inputPassword4">Lote</label>
      <input type="text" class="form-control" name="lote" id="inputPassword4" placeholder="Lote" value="<?php echo e($producto->prod_lote); ?>">
    </div>



    <div class="form-group col-md-6">
      <label for="inputPassword4">Serie</label>
      <input type="text" class="form-control" name="serie" id="inputPassword4" placeholder="Serie" value="<?php echo e($producto->prod_serie); ?>">
    </div>

    
  </div>






  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="cbo_presentacion_id">Presentacion</label>

      <select class="form-control" aria-label="Default select example" name="cbo_presentacion" id="cbo_presentacion_id"
       v-model="cbo_presentacion_id">
      <?php echo e($guion  =""); ?>;
        <?php $__currentLoopData = $presentaciones->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <option value=<?php echo e($index); ?>  <?php if($producto->pres_id ==$index): ?> selected <?php endif; ?>><?php echo e($index.$guion.$value); ?></option>
            <?php echo e(@$guion  =" - "); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
 
   </div>


    <div class="form-group col-md-6">
    <label for="inputAddress">Precio</label>
        <input type="number" class="form-control" id="inputAddress" placeholder="Precio" name="precio" value="<?php echo e($producto->prod_precio); ?>">    </div>

    
  </div>



 





 
  <div class="form-group">
    
  <label for="empresa_id">Empresa</label>
      <select v-model="empresa_id" id="empresa_id" data-old="<?php echo e(old('cbo_empresa')); ?>"
      name="cbo_empresa"  class="form-control">
      <?php echo e($guion  =""); ?>;
        <?php $__currentLoopData = $empresas->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <option value=<?php echo e($index); ?>  <?php if($producto->empr_id ==$index): ?> selected <?php endif; ?>><?php echo e($index.$guion.$value); ?></option>
            <?php echo e(@$guion  =" - "); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
 
  </div>




    <div class="form-group">
      <label for="inputEmail4">Comentario</label>
      
      <textarea class="form-control" id="comentario_id" name="comentario" rows="3" placeholder="Comentario"><?php echo e($producto->prod_comentario); ?></textarea>
    </div>
 



  <button type="submit" class="btn btn-primary">Actualizar</button>
  <button type="reset" class="btn btn-danger">Cancelar</button>

</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/productos.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/productos/edit.blade.php ENDPATH**/ ?>