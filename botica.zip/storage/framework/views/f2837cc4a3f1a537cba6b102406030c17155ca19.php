

<?php $__env->startSection('content'); ?>



<div class="container">

<div class="row">
<div class="col-md-8">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h4>Por Favor corriga los siguientes errores   </h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>

   <form action="<?php echo e(route('empresas.update',$empresa->empr_id)); ?>" method="POST">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>


  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Empresa</label>
      <input type="text" class="form-control" name="nombre" id="inputEmail4" placeholder="Nombre" value="<?php echo e($empresa->empr_nombre); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Ruc</label>
      <input type="number" maxlength="10" class="form-control" name="ruc" id="inputPassword4" placeholder="Ruc" value="<?php echo e($empresa->empr_ruc); ?>">
    </div>
  </div>


  <div class="form-group">
    <label for="inputAddress">Direccion</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Direccion" name="direccion" value="<?php echo e($empresa->empr_direccion); ?>">
  </div>

  <div class="form-group">
    <label for="inputAddress">Email</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Email" name="correo" value="<?php echo e($empresa->empr_correo); ?>">
  </div>


  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Telefono</label>
      <input  type="number" maxlength="9"  class="form-control" name="telefono" id="inputEmail4" placeholder="Telefono" value="<?php echo e($empresa->empr_telefono); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Celular</label>
      <input type="number" maxlength="9" class="form-control" name="celular" id="inputPassword4" placeholder="Celular" value="<?php echo e($empresa->empr_celular); ?>">
    </div>
  </div>

 

  <button type="submit" class="btn btn-primary">Actualizar</button>
  <button type="reset" class="btn btn-danger">Cancelar</button>

</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/empresas/edit.blade.php ENDPATH**/ ?>