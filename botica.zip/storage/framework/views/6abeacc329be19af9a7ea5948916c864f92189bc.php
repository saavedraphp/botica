

<?php $__env->startSection('content'); ?>

<div class="container">
<h2>Lista de Empresas 
  <a href="empresas/create"> <button type="button" class="btn btn-success float-right">Adicionar</button></a>
  

</h2>

<?php if($search): ?>
<h6><div class="alert alert-primary" role="alert">
  Resultado de la busqueda '<?php echo e($search); ?>'
  </div>
</h6>
<?php endif; ?>


<?php if(Session::get('operacion')=='1'): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>

<?php if(Session::get('operacion')=='0'): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <?php echo e(Session::get('message')); ?>

  </div>

<?php endif; ?>


<table class="table table-hover" >
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Empresa</th>
      <th scope="col">Ruc</th>      
      <th scope="col">Email</th>
      <th scope="col">Telefono</th>
      <th scope="col">Opciones</th>
    </tr>
  </thead>
  <tbody id="userList">
  	<?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr v-for>
      <th scope="row"> <?php echo e($empresa->empr_id); ?> </th>
      <td><?php echo e($empresa->empr_nombre); ?></td>
      <td><?php echo e($empresa->empr_ruc); ?></td>
      <td><?php echo e($empresa->empr_correo); ?></td>
      <td><?php echo e($empresa->empr_telefono); ?></td>

      <td>


        <form action="<?php echo e(route('empresas.destroy',$empresa->empr_id)); ?>" method="POST" id="frm_destroy<?php echo e($empresa->empr_id); ?>"> 
          <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>


        <a href="<?php echo e(route('casillas_add',$empresa->empr_id)); ?>" title="<?php echo e(MiConstantes::ASIGNAR_CASILLAS); ?>"> <i class="fas fa-border-none"></i></a> |
        <a href="<?php echo e(route('imagesHead',$empresa->empr_id)); ?>" title="<?php echo e(MiConstantes::IMG_REPORTE); ?>"> <i class="far fa-images" ></i></a> |
         <a href="<?php echo e(route('empresas.edit',$empresa->empr_id)); ?>" title="<?php echo e(MiConstantes::EDITAR); ?>"> <i class="far fa-edit" ></i></a> |
         
         <a title="<?php echo e(MiConstantes::ELIMINAR); ?>" href="javascript:document.getElementById('frm_destroy<?php echo e($empresa->empr_id); ?>').submit();" onclick="return confirm('Estas Seguro de Borrar el Registro Id:<?php echo e($empresa->empr_id); ?>');"><i class="fas fa-trash-alt"></i></a>

        </form>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div class="row">
  <div class="mx-auto"><?php echo e($empresas->links()); ?></div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/user-list.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/empresas/index.blade.php ENDPATH**/ ?>