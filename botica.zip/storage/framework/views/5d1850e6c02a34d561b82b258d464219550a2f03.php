

<?php $__env->startSection('content'); ?>

<div class="container">
<h2>Lista de Usuarios 
  <a href="usuarios/create"> <button type="button" class="btn btn-success float-right">Adicionar</button></a>
  <a href="<?php echo e(route('users.pdf')); ?>"> <button type="button" class="btn btn-success float-right">Exportar PDF</button></a>

</h2>

<?php if($search): ?>
<h6><div class="alert alert-primary" role="alert">
  Resultado de la busqueda '<?php echo e($search); ?>'
  </div>
</h6>
<?php endif; ?>

<table class="table table-hover" >
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
 
    </tr>
  </thead>
  <tbody id="userList">
   

    <tr v-for>
      <th scope="row"> </th>
      <td></td>
 
      <td>


        <form action="" method="POST">
          <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>

         <a href=""> <button type="button" class="btn btn-secondary">Ver</button></a>

         <a href=""> <button type="button" class="btn btn-danger">Editar</button></a>

         <button type="submit" class="btn btn-primary">Eliminar</button>

        </form>

      </td>
    </tr>
    
    
  </tbody>
</table>

<div class="row">
  <div class="mx-auto">paginacion</div>
</div>
</div>
<div> {{data}}</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/admin/task/index.blade.php ENDPATH**/ ?>