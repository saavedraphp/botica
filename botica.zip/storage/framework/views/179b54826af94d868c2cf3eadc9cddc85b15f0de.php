

<?php $__env->startSection('content'); ?>

<div class="container">
<h2>Importar Data de Excel 
  <a href="productos/create"> <button type="button" class="btn btn-success float-right">Adicionar</button></a>
  

</h2>
 


<?php if(Session::get('operacion')=='1'): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>

<?php if(Session::get('operacion')=='0'): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <?php echo e(Session::get('message')); ?>

  </div>

<?php endif; ?>
 




<form action="<?php echo e(route('products.import.excel')); ?>" method="POST" 
id="frm_formulario" enctype="multipart/form-data" >

<?php echo csrf_field(); ?>
 
  <div class="form-group">
        <label for="inputAddress">Imagen</label>
        <div class="input-group mb-3">

            <div class="input-group-prepend">
                <span class="input-group-text">Archivo</span>
            </div>

            <div class="custom-file">
                <input type="file" class="custom-file-input" id="img_cabecera"    ref="imagen" name="img">
                <label class="custom-file-label" for="inputGroupFile01">Seleccione Archivo</label>
            </div>
        
        </div>
  </div>

 

 

  <button type="submit" class="btn btn-primary">Cargar Datos</button>

 
</form> 
 
</div>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\botica\resources\views/productos/importar.blade.php ENDPATH**/ ?>