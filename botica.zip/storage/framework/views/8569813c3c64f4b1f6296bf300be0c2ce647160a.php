

<?php $__env->startSection('content'); ?>


<?php $paises = app('App\Services\Paises'); ?>
<div class="container">

<div class="row">
<div class="col-md-8">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h4>Por Favor corriga los siguientes errores   </h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>

<form action="/admin/empresas" method="POST"  id="frm_formulario" @submit="checkForm">
<?php echo csrf_field(); ?>

<p v-if="errors.length">
    <b style="color: red;">Por favor, corrija el(los) siguiente(s) error(es):</b>
    <ul>
      <li v-for="error in errors">{{error}}</li>
    </ul>
  </p>


  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Empresa</label>
      <input type="text" class="form-control" v-model="nombre_id" name="nombre" id="nombre_id" placeholder="Nombre" value="<?php echo e(old('nombre')); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Ruc</label>
      <input type="number"   onKeyPress="if(this.value.length==11) return false;"   class="form-control" name="ruc" id="inputPassword4" placeholder="Ruc" value="<?php echo e(old('ruc')); ?>">
    </div>
  </div>


  <div class="form-group">
    <label for="inputAddress">Direccion</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Direccion" name="direccion" value="<?php echo e(old('direccion')); ?>">
  </div>

  <div class="form-group">
    <label for="inputAddress">Email</label>
    <input   type="text" class="form-control"   v-model="correo_id"  id="correo_id" placeholder="Email" name="correo" 
    value="<?php echo e(old('correo')); ?>"  @blur="existeEmail" >
    <span    v-if="encontroEmail" class="alert alert-danger">El correo existe en nuestra base de datos</span>
  </div>


  <div class="form-row">

    <div class="form-group col-md-6">
      <label for="inputPassword4">Celular</label>
      <input type="number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==9) return false;" class="form-control" v-model="celular_id" name="celular" id="celular_id" placeholder="Celular" value="<?php echo e(old('celular')); ?>">
    </div>


    <div class="form-group col-md-6">
      <label for="inputEmail4">Telefono</label>
      <input type="number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==9) return false;" class="form-control" name="telefono" id="inputEmail4" placeholder="Telefono" value="<?php echo e(old('telefono')); ?>">
    </div>

  </div>

 

  <button type="submit" class="btn btn-primary">Registrar</button>
  <button type="reset" class="btn btn-danger">Cancelar</button>

</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
  const url = '<?php echo e(env('MY_URL')); ?>';
  
</script>
<script src="<?php echo e(asset('js/frm_empresa.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/empresas/create.blade.php ENDPATH**/ ?>