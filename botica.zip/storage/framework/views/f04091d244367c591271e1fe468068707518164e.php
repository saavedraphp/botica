<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(MiConstantes::TITULO); ?></title>

    <!-- Scripts -->
 
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
    <script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>


    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">

    
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
    
</head>


<body class="hold-transition sidebar-mini layout-fixed">
    <div id="app">
        <div class="wrapper">

            <!-- Navbar -->
            
            <nav class="main-header navbar navbar-expand navbar-white navbar-light">
                <!-- Left navbar links -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
                    </li>
                </ul>

                <!-- SEARCH FORM -->
                <form class="form-inline ml-3">
                    <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" type="search" placeholder="Search"
                            aria-label="Search" name="search">
                        <div class="input-group-append">
                            <button class="btn btn-navbar" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Right navbar links -->
                <ul class="navbar-nav ml-auto">
                    <!-- Messages Dropdown Menu -->
                    <li class="nav-item dropdown">
                        <a class="nav-link" data-toggle="dropdown" href="#">
                            <i class="far fa-comments"></i>
                            <span class="badge badge-danger navbar-badge">3</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <a href="#" class="dropdown-item">
                                <!-- Message Start -->
                                <div class="media">
                                    <img src="<?php echo e(asset('dist/img/user1-128x128.jpg')); ?>" alt="User Avatar"
                                        class="img-size-50 mr-3 img-circle">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            Brad Diesel
                                            <span class="float-right text-sm text-danger"><i
                                                    class="fas fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">Call me whenever you can...</p>
                                        <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <!-- Message Start -->
                                <div class="media">
                                    <img src="<?php echo e(asset('dist/img/user8-128x128.jpg')); ?>" alt="User Avatar"
                                        class="img-size-50 img-circle mr-3">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            John Pierce
                                            <span class="float-right text-sm text-muted"><i
                                                    class="fas fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">I got your message bro</p>
                                        <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <!-- Message Start -->
                                <div class="media">
                                    <img src="<?php echo e(asset('dist/img/user3-128x128.jpg')); ?>" alt="User Avatar"
                                        class="img-size-50 img-circle mr-3">
                                    <div class="media-body">
                                        <h3 class="dropdown-item-title">
                                            Nora Silvester
                                            <span class="float-right text-sm text-warning"><i
                                                    class="fas fa-star"></i></span>
                                        </h3>
                                        <p class="text-sm">The subject goes here</p>
                                        <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                                    </div>
                                </div>
                                <!-- Message End -->
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
                        </div>
                    </li>
                    <!-- Notifications Dropdown Menu -->
                    <li class="nav-item dropdown">
                        <a class="nav-link" data-toggle="dropdown" href="#">
                            <i class="far fa-bell"></i>
                            <span class="badge badge-warning navbar-badge">15</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <span class="dropdown-item dropdown-header">15 Notifications</span>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-envelope mr-2"></i> 4 new messages
                                <span class="float-right text-muted text-sm">3 mins</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-users mr-2"></i> 8 friend requests
                                <span class="float-right text-muted text-sm">12 hours</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-file mr-2"></i> 3 new reports
                                <span class="float-right text-muted text-sm">2 days</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
                        </div>
                    </li>
                </ul>
            </nav>
            <!-- /.navbar -->

            <!-- Main Sidebar Container -->
            <aside class="main-sidebar sidebar-dark-primary elevation-4 ">
                <!-- Brand Logo -->
                <a href="<?php echo e(url('/')); ?>" class="brand-link">
                    <img src="<?php echo e(asset('dist/img/almagrilogo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" >
                    <span class="brand-text font-weight-light">SYS-Almacen</span>
                </a>
                <!-- Sidebar -->
                <div class="sidebar">
                    <!-- Sidebar user panel (optional) -->
                    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                        <div class="image">
                        <a href="#" class="search-results-gallery-icon flex flex-column items-center justify-center color-inherit w-100 pa2 br2 br--top no-underline hover-bg-blue4 hover-white">
                            <i class="fas fa-user-alt" style="font-size: 48px;"></i>
                        </a>                    
                    </div>
                    
                        <div class="info">
                            <a href="#" class="d-block">
                                <?php if(auth()->guard()->guest()): ?>
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar Sesión')); ?></a>
                                <?php else: ?>
                                <?php echo e(Auth::user()->name); ?>

                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                           document.getElementById('logout-form').submit();">
                                    <spand style="color:#959e97">Cerrar Sesión</spand>
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>

                                <?php endif; ?>
                            </a>
                        </div>
                    </div>

                    <!-- Sidebar Menu -->
                    <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                            <li class="nav-item">
                                <a href="/admin" class="<?php echo e(Request::path() === '/' ? 'nav-link active' : 'nav-link'); ?>">
                                    <i class="nav-icon fas fa-home"></i>
                                    <p>Inicio</p>
                                </a>
                            </li>


                            <li class="nav-item">
                                <a href="/admin/actas"
                                    class="<?php echo e(Request::path() === 'productos' ? 'nav-link active' : 'nav-link'); ?>">
                                    
                                    <i class="nav-icon fas fa-plus-circle"></i>
                                    <p>
                                        Actas
                                        <?php use App\Acta;
$count = Acta::all()->count();?>
                                        <span class="right badge badge-danger"><?php echo e($count ?? '0'); ?></span>
                                    </p>
                                </a>
                            </li>





                            <li class="nav-item">
                                <a href="/admin/empresas"
                                    class="<?php echo e(Request::path() === 'empresas' ? 'nav-link active' : 'nav-link'); ?>">

                                    <i class="nav-icon fas fa-university"></i>
                                    <p>
                                        Empresas
                                        <?php use App\Empresa;
$empresa_count = Empresa::all()->count();?>
                                        <span class="right badge badge-danger"><?php echo e($empresa_count ?? '0'); ?></span>
                                    </p>
                                </a>
                            </li>


                            <li class="nav-item">
                                <a href="/admin/productos"
                                    class="<?php echo e(Request::path() === 'productos' ? 'nav-link active' : 'nav-link'); ?>">
                                    
                                    <i class="nav-icon fas fa-cubes"></i>
                                    <p>
                                        Productos
                                        <?php use App\Producto;
$producto_count = Producto::all()->count();?>
                                        <span class="right badge badge-danger"><?php echo e($producto_count ?? '0'); ?></span>
                                    </p>
                                </a>
                            </li>
                            
 

 



                            <li class="<?php echo e((Request::path() == 'admin/racks' or Request::path() == 'admin/casillas')  ? 'nav-item menu-open' : 'nav-item'); ?>" >
                                <a href="/admin/casillas" class="nav-link" >
                                <i class="nav-icon fas fa-edit"></i>
                                <p>
                                    Almacen
                                    <i class="fas fa-angle-left right"></i>
                                </p>
                                </a>
                                <ul class="nav nav-treeview">
                                
                                <li class="nav-item">
                                    <a href="/admin/racks" class="<?php echo e(Request::path() === 'admin/racks' ? 'nav-link active' : 'nav-link'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <?php use App\Rack;
                                    $rack_count = Rack::all()->count();?>
                                    <p>Racks </p>
                                    <span class="right badge badge-danger"><?php echo e($rack_count ?? '0'); ?></span>
                                    </a>
                                </li>



                                <li class="nav-item">
                                    <a href="/admin/casillas" class="<?php echo e(Request::path() === 'admin/casillas' ? 'nav-link active' : 'nav-link'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <?php use App\RackCasillas;
                                    $casillas_count = RackCasillas::all()->count();?>
                                    <p>Casillas </p>
                                    <span class="right badge badge-danger"><?php echo e($casillas_count ?? '0'); ?></span>
                                    </a>
                                </li>


                                </ul>
                            </li>



                            


                            



                        </ul>
                    </nav>
                    <!-- /.sidebar-menu -->
                </div>
                <!-- /.sidebar -->
            </aside>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header">

                </div>
                <!-- /.content-header -->

                <!-- Main content -->
                <section class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
            <footer class="main-footer">
                <!-- NO QUITAR -->
                <strong>Desarrollado por AdeconPeru
                        <div class="float-right d-none d-sm-    -block">
                        <b>Version</b> 1.0
                    </div>
            </footer>

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Control sidebar content goes here -->
            </aside>
            <!-- /.control-sidebar -->
        </div>
    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
<!-- jQuery -->
 
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
 

</body>
</html><?php /**PATH C:\wamp64\www\admin\resources\views/layouts/app.blade.php ENDPATH**/ ?>